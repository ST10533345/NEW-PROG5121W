/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.capp;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Scanner;
/**
*
 * @author GHOST
 */
public class CAPP {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Login> users = new ArrayList<>();

        System.out.println("\nWelcome to APPCHAT! Please choose an option.");

        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1: // Registration
                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();

                    // Validate username
                    boolean validUsername = username.contains("_") && username.length() > 5;
                    if (!validUsername) {
                        System.out.println("Username must contain an underscore (_) and be longer than 5 characters.");
                        break;
                    }

                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();

                    // Validate password
                    boolean validPassword = password.length() >= 8 &&
                            password.matches(".*[A-Z].*") &&
                            password.matches(".*\\d.*") &&
                            password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
                    if (!validPassword) {
                        System.out.println("Password must be at least 8 characters long, contain an uppercase letter, a number, and a special character.");
                        break;
                    }

                    System.out.print("Enter South African phone number (e.g., +27831234567): ");
                    String phoneNumber = scanner.nextLine();

                    // Validate phone number
                    String regex = "\\+27[6-8]\\d{8}";
                    if (!phoneNumber.matches(regex)) {
                        System.out.println("Invalid phone number format! Use +27XXXXXXXXX.");
                        break;
                    }

                    // Check if username already exists
                    boolean userExists = users.stream().anyMatch(u -> u.getUsername().equals(username));
                    if (userExists) {
                        System.out.println("Username already exists. Please choose another.");
                        break;
                    }

                    // Add the new user
                    users.add(new Login(username, password, phoneNumber));
                    System.out.println("User registered successfully!");

                    // After registration, prompt for login
                    promptLogin(scanner, users);
                    break;

                case 2: // Login
                    if (users.isEmpty()) {
                        System.out.println("No users registered yet. Please register first.");
                        break;
                    }
                    promptLogin(scanner, users);
                    break;

                case 3: // Exit
                    System.out.println("Goodbye");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option. Please choose 1, 2, or 3.");
            }
        }
    }

    // Method to handle login logic
    private static void promptLogin(Scanner scanner, ArrayList<Login> users) {
        System.out.print("Enter username: ");
        String enteredUsername = scanner.nextLine();
        System.out.print("Enter password: ");
        String enteredPassword = scanner.nextLine();

        // Find user
        Login user = users.stream()
                .filter(u -> u.getUsername().equals(enteredUsername))
                .findFirst()
                .orElse(null);

        boolean loginStatus = user != null && user.loginUser(enteredPassword);
        System.out.println(user != null ? user.returnLoginStatus(loginStatus) : "User not found.");
    }
}

// Login class
class Login {
    private String username;
    private String passwordHash;
    private String phoneNumber;
    private byte[] salt;

    public Login(String username, String password, String phoneNumber) {
        this.username = username;
        this.salt = generateSalt(); // Generate salt
        this.passwordHash = hashPassword(password, salt);
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public boolean loginUser(String enteredPassword) {
        String hash = hashPassword(enteredPassword, salt);
        return this.passwordHash.equals(hash);
    }

    public String returnLoginStatus(boolean status) {
        return status ? "Login successful!" : "Invalid username or password.";
    }

    // Hash password with a salt using SHA-256
    private String hashPassword(String password, byte[] salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt); // Add salt to the hash
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }

    // Generate a random salt for password hashing
    private byte[] generateSalt() {
        try {
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[16];
            random.nextBytes(salt);
            return salt;
        } catch (Exception e) {
            throw new RuntimeException("Error generating salt", e);
        }
    }
}
    
          
                
                    
                    
                
                
                
                
                
                
                
                
                
                
        
        
