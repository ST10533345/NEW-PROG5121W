/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.capp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author GHOST
 */
public class CAPPIT {
    
    public CAPPIT() {
    }

    /**
     * Test of main method, of class CAPP.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        CAPP.main(args);
        fail("The test case is a prototype.");
    }
    
}
