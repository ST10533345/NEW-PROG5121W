/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package com.mycompany.capp;

import static org.testng.Assert.*;
import org.testng.annotations.Test;

/**
 *
 * @author GHOST
 */
public class CAPPNGTest {
    
    public CAPPNGTest() {
    }

    /**
     * Test of main method, of class CAPP.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        CAPP.main(args);
        fail("The test case is a prototype.");
    }
    
}
