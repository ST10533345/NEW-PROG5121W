/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package com.mycompany.capp;

import static org.testng.Assert.*;
import org.testng.annotations.Test;

/**
 *
 * @author GHOST
 */
public class LoginNGTest {
    
    public LoginNGTest() {
    }

    /**
     * Test of getUsername method, of class Login.
     */
    @Test
    public void testGetUsername() {
        System.out.println("getUsername");
        Login instance = null;
        String expResult = "";
        String result = instance.getUsername();
        assertEquals(result, expResult);
        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class Login.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String enteredPassword = "";
        Login instance = null;
        boolean expResult = false;
        boolean result = instance.loginUser(enteredPassword);
        assertEquals(result, expResult);
        fail("The test case is a prototype.");
    }

    /**
     * Test of returnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        boolean status = false;
        Login instance = null;
        String expResult = "";
        String result = instance.returnLoginStatus(status);
        assertEquals(result, expResult);
        fail("The test case is a prototype.");
    }
    
}
