/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.capp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author GHOST
 */
public class LoginTest {
    
    public LoginTest() {
    }

    /**
     * Test of getUsername method, of class Login.
     */
    @Test
    public void testGetUsername() {
        System.out.println("getUsername");
        Login instance = null;
        String expResult = "";
        String result = instance.getUsername();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class Login.
     */
    @Test
    public void testLoginUser_1args_1() {
        System.out.println("loginUser");
        String enteredPassword = "";
        Login instance = null;
        boolean expResult = false;
        boolean result = instance.loginUser(enteredPassword);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of returnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        boolean status = false;
        Login instance = null;
        String expResult = "";
        String result = instance.returnLoginStatus(status);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of LoginUser method, of class Login.
     */
    @Test
    public void testLoginUser_1args_2() {
        System.out.println("LoginUser");
        String enteredPassword = "";
        Login instance = null;
        boolean expResult = false;
        boolean result = instance.LoginUser(enteredPassword);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }
    
}
