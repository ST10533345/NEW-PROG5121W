/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package com.mycompany.capp;

import static org.testng.Assert.*;
import org.testng.annotations.Test;

/**
 *
 * @author GHOST
 */
public class secureRandomNGTest {
    
    public secureRandomNGTest() {
    }

    @Test
    public void testSomeMethod() {
        fail("The test case is a prototype.");
    }
    
}
